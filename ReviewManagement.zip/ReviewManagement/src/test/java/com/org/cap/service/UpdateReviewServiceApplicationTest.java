package com.org.cap.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.org.cap.entities.Review;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class UpdateReviewServiceApplicationTest {
	@Autowired
	ReviewService reviewService;

	@Autowired
	TestRestTemplate testRestTemplate;

	@Test
	public void testGetReviewByCustomerId_Positive() throws Exception {
		Optional<List<Review>> review = reviewService.getReviewByMailId("abc@gmail.com");
		Assertions.assertEquals(true, review.isPresent());
	}

	@Test
	public void testGetReviewByBookId_Positive() throws Exception {
		Optional<List<Review>> review = reviewService.getReviewByBookId(53);
		Assertions.assertEquals(true, review.isPresent());
	}

	@Test
	public void testGetReviewByCustomerId_Negative() throws Exception {
		Optional<List<Review>> review = reviewService.getReviewByMailId("sycdj@gmail.com");
		Assertions.assertEquals(false, review.isPresent());
	}

	@Test
	public void testGetReviewByBookId_Negative() throws Exception {
		Optional<List<Review>> review = reviewService.getReviewByBookId(100);
		Assertions.assertEquals(false, review.isPresent());
	}

	@Test
	public void testGetReviews_Negative() throws Exception {
		List<Review> review = reviewService.getReviews();
		Assertions.assertEquals(false, review.isEmpty());
	}

	public void setTestRestTemplate(TestRestTemplate testRestTemplate) {
		this.testRestTemplate = testRestTemplate;
	}

	@LocalServerPort
	int localServerPort;

	@Test
	public void testGetReviewByCustomId_Positive() throws Exception {
		String url = "http://localhost:" + localServerPort + "/Review/getReviewByMailId/'xyz@gmail.com'";
		ResponseEntity<Review> review = testRestTemplate.getForEntity(url, Review.class);
		Assertions.assertEquals(404, review.getStatusCodeValue());
	}

	@Test
	public void testGetReviewByCustomId_Negative() throws Exception {
		String url = "http://localhost:" + localServerPort + "/getReviewByCustomerId/9";
		ResponseEntity<Review> review = testRestTemplate.getForEntity(url, Review.class);
		Assertions.assertEquals(404, review.getStatusCodeValue());
	}

	@Test
	public void testGetReviewByBookIdPositive() throws Exception {
		String url = "http://localhost:" + localServerPort + "/getReviewByBookId/1";
		ResponseEntity<Review> review = testRestTemplate.getForEntity(url, Review.class);
		Assertions.assertEquals(404, review.getStatusCodeValue());
	}

	@Test
	public void testGetReviewByBookIdNegative() throws Exception {
		String url = "http://localhost:" + localServerPort + "/getReviewByBookId/9";
		ResponseEntity<Review> review = testRestTemplate.getForEntity(url, Review.class);
		Assertions.assertEquals(404, review.getStatusCodeValue());
	}

	@Test
	public void testGetReviews_Positive() throws Exception {
		String url = "http://localhost:" + localServerPort + "/getReviews";
		ResponseEntity<Review> review = testRestTemplate.getForEntity(url, Review.class);
		Assertions.assertEquals(404, review.getStatusCodeValue());
	}

	@Test
	public void testGetReviewsNegative() throws Exception {
		String url = "http://localhost:" + localServerPort + "/getReviews";
		ResponseEntity<Review> review = testRestTemplate.getForEntity(url, Review.class);
		Assertions.assertEquals(404, review.getStatusCodeValue());
	}

	@Test
	public void testinsertReview_Negative() throws Exception {
		Review review = new Review();
		ResponseEntity<Review> r = reviewService.createReview(review);
		Assertions.assertEquals(r.getBody().getReviewId(), review.getReviewId());

	}

	@Test
	public void testinsertReview_Positive() throws Exception {
		Review review = new Review(1, null, null, 4, "good", "abc");
		ResponseEntity<Review> r = reviewService.createReview(review);
		Assertions.assertEquals(r.getBody().getReviewId(), review.getReviewId());
	}

	@Test
	public void testupdatetReview_null() throws Exception {
		Review review = new Review();
		ResponseEntity<Review> r = reviewService.updateReview(review);
		Assertions.assertEquals(r.getBody().getReviewId(), review.getReviewId());

	}

	@Test
	public void testupdateReview_updating() throws Exception {
		Review review = new Review(1, 4, "good", "abc");
		ResponseEntity<Review> r = reviewService.updateReview(review);
		Assertions.assertEquals(r.getBody().getReviewId(), review.getReviewId());
	}

	@Test
	public void testupdateReview_create() throws Exception {
		Review review = new Review(45, 4, "good", "abc");
		ResponseEntity<Review> r = reviewService.updateReview(review);
		Assertions.assertEquals(r.getBody().getReviewId(), review.getReviewId());
	}

	@Test
	public void testupdateReview_rating() throws Exception {
		Review review = new Review(1, 5, "good", "abcd");
		ResponseEntity<Review> r = reviewService.updateReview(review);
		Assertions.assertEquals(r.getBody().getReviewId(), review.getReviewId());
	}

	@Test
	public void testDelete() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:8084/Review/deleteReview/1";// Enter present id 
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.DELETE, null, String.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}

	@Test
	public void testDelete_Null() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:8084/Review/deleteReview/85";// Enter present id
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.DELETE, null, String.class);
		Assert.assertEquals(null, result.getBody());
	}

	@Test
	public void testUpdateReview() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + 8084 + "/Review/UpdateReview";
		URI uri = new URI(baseUrl);
		Review review = new Review(11, 4, "good", "abc");
		ResponseEntity<Review> result = restTemplate.exchange(uri, HttpMethod.PUT, new HttpEntity<>(review),
				Review.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertNotNull(result);
	}

	@Test
	public void testUpdateReview_Rating() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + 8084 + "/Review/UpdateReview";
		URI uri = new URI(baseUrl);
		Review review = new Review(11, 4, "good", "abc");
		ResponseEntity<Review> result = restTemplate.exchange(uri, HttpMethod.PUT, new HttpEntity<>(review),
				Review.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertNotNull(result);
	}
}
