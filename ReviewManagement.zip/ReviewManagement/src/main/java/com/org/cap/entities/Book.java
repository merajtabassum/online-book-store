package com.org.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book")
public class Book {
	@Id
	@Column(length = 20,name = "bookId")
	private int bookId;
	@Column(name = "categoryId")
	private String categoryId;
	@Column(length = 128,name = "title")
	private String title;
	@Column(length = 64,name = "author")
	private String author;
	@Column(length = 15,name = "isbn")
	private String isbn;
	@Column(name = "price")
	private float price;
	
	public Book() {	}

	public Book(int bookId, String categoryId, String title, String author, String isbn, float price)
	{
		this.bookId = bookId;
		this.categoryId = categoryId;
		this.title = title;
		this.author = author;
		this.isbn = isbn;
		this.price = price;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getCategory() {
		return categoryId;
	}

	public void setCategory(String category) {
		this.categoryId = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getIsbnNo() {
		return isbn;
	}

	public void setIsbnNo(String isbn) {
		this.isbn = isbn;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", category=" + categoryId + ", title=" + title + ", author=" + author
				+ ", isbnNo=" + isbn + ", price=" + price + "]";
	}
	
	
}
