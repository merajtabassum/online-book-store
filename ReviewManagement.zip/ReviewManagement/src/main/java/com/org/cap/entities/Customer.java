package com.org.cap.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
@SequenceGenerator(name = "customer_id_gen", initialValue = 10000, allocationSize = 1)
public class Customer {

	@GeneratedValue(generator = "customer_id_gen", strategy = GenerationType.SEQUENCE)
	@Column(name = "customer_id")
	int customerId;
	@Column(name = "name")
	String Name;
	@Id
	@Column(name = "emailId")
	String emailId;
	@Column(name = "password")
	String password;
	@Column(name = "phone")
	Long phone;
	@Column(name = "address")
	String address;
	@Column(name = "city")
	String city;
	@Column(name = "country")
	String country;
	@Column(name = "zipcode")
	Long zipCode;

	public Customer() {

	}

	public Customer(int customerId, String Name, String emailId, String password, Long phone,
			String address, String city, String country, Long zipCode) {
		super();
		this.customerId = customerId;
		this.Name = Name;
		this.emailId = emailId;
		this.password = password;
		this.phone = phone;
		this.address = address;
		this.city = city;
		this.country = country;
		this.zipCode = zipCode;

	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFullName() {
		return Name;
	}

	public void setFullName(String Name) {
		this.Name = Name;
	}

	public String getEmailAddress() {
		return emailId;
	}

	public void setEmailAddress(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getPhoneNumber() {
		return phone;
	}

	public void setPhoneNumber(Long phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Long getZipCode() {
		return zipCode;
	}

	public void setZipCode(Long zipCode) {
		this.zipCode = zipCode;
	}

}
