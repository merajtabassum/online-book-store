package com.org.cap.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "review")
public class Review {
	@Id
	//@Column(length = 200)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int reviewId;
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "book_id")
	private Book bookId;
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "mailId")
	private Customer customerId;
	@Column(name = "rating")
	private int rating;
	@Column( name = "headline")
	private String headline;
	@Column(name = "comments")
	private String comments;

	public Review() {
	}

	public Review(int reviewId, Book bookId, Customer customerId, int rating, String headline, String comments) {
		this.reviewId = reviewId;
		this.bookId = bookId;
		this.customerId = customerId;
		this.rating = rating;
		this.headline = headline;
		this.comments = comments;
	}

	public Review(int reviewId, int rating, String headline, String comments) {
		super();
		this.reviewId = reviewId;
		this.rating = rating;
		this.headline = headline;
		this.comments = comments;
	}

	public int getReviewId() {
		return reviewId;
	}

	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}

	public Book getBook() {
		return bookId;
	}

	public void setBook(Book book) {
		this.bookId = book;
	}

	public Customer getCustomer() {
		return customerId;
	}

	public void setCustomer(Customer customer) {
		this.customerId = customer;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", book=" + bookId + ", customer=" + customerId + ", rating=" + rating
				+ ", headline=" + headline + ", comments=" + comments + "]";
	}
}
